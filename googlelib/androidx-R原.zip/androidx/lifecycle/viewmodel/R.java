//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package androidx.lifecycle.viewmodel;

public final class R {
    public R() {
    }
}
