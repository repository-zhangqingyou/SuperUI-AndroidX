//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package androidx.cardview;

public final class R {
    public R() {
    }

    public static final class styleable {
        public static final int[] CardView;
        public static final int CardView_android_minHeight;
        public static final int CardView_android_minWidth;
        public static final int CardView_cardBackgroundColor;
        public static final int CardView_cardCornerRadius;
        public static final int CardView_cardElevation;
        public static final int CardView_cardMaxElevation;
        public static final int CardView_cardPreventCornerOverlap;
        public static final int CardView_cardUseCompatPadding;
        public static final int CardView_contentPadding;
        public static final int CardView_contentPaddingBottom;
        public static final int CardView_contentPaddingLeft;
        public static final int CardView_contentPaddingRight;
        public static final int CardView_contentPaddingTop;

        public styleable() {
        }

        static {
            CardView = R.styleable.CardView;
            CardView_android_minHeight = R.styleable.CardView_android_minHeight;
            CardView_android_minWidth = R.styleable.CardView_android_minWidth;
            CardView_cardBackgroundColor = R.styleable.CardView_cardBackgroundColor;
            CardView_cardCornerRadius = R.styleable.CardView_cardCornerRadius;
            CardView_cardElevation = R.styleable.CardView_cardElevation;
            CardView_cardMaxElevation = R.styleable.CardView_cardMaxElevation;
            CardView_cardPreventCornerOverlap = R.styleable.CardView_cardPreventCornerOverlap;
            CardView_cardUseCompatPadding = R.styleable.CardView_cardUseCompatPadding;
            CardView_contentPadding = R.styleable.CardView_contentPadding;
            CardView_contentPaddingBottom = R.styleable.CardView_contentPaddingBottom;
            CardView_contentPaddingLeft = R.styleable.CardView_contentPaddingLeft;
            CardView_contentPaddingRight = R.styleable.CardView_contentPaddingRight;
            CardView_contentPaddingTop = R.styleable.CardView_contentPaddingTop;
        }
    }

    public static final class style {
        public static final int Base_CardView;
        public static final int CardView;
        public static final int CardView_Dark;
        public static final int CardView_Light;

        public style() {
        }

        static {
            Base_CardView = R.style.Base_CardView;
            CardView = R.style.CardView;
            CardView_Dark = R.style.CardView_Dark;
            CardView_Light = R.style.CardView_Light;
        }
    }

    public static final class dimen {
        public static final int cardview_compat_inset_shadow;
        public static final int cardview_default_elevation;
        public static final int cardview_default_radius;

        public dimen() {
        }

        static {
            cardview_compat_inset_shadow = R.dimen.cardview_compat_inset_shadow;
            cardview_default_elevation = R.dimen.cardview_default_elevation;
            cardview_default_radius = R.dimen.cardview_default_radius;
        }
    }

    public static final class color {
        public static final int cardview_dark_background;
        public static final int cardview_light_background;
        public static final int cardview_shadow_end_color;
        public static final int cardview_shadow_start_color;

        public color() {
        }

        static {
            cardview_dark_background = R.color.cardview_dark_background;
            cardview_light_background = R.color.cardview_light_background;
            cardview_shadow_end_color = R.color.cardview_shadow_end_color;
            cardview_shadow_start_color = R.color.cardview_shadow_start_color;
        }
    }

    public static final class attr {
        public static final int cardBackgroundColor;
        public static final int cardCornerRadius;
        public static final int cardElevation;
        public static final int cardMaxElevation;
        public static final int cardPreventCornerOverlap;
        public static final int cardUseCompatPadding;
        public static final int cardViewStyle;
        public static final int contentPadding;
        public static final int contentPaddingBottom;
        public static final int contentPaddingLeft;
        public static final int contentPaddingRight;
        public static final int contentPaddingTop;

        public attr() {
        }

        static {
            cardBackgroundColor = R.attr.cardBackgroundColor;
            cardCornerRadius = R.attr.cardCornerRadius;
            cardElevation = R.attr.cardElevation;
            cardMaxElevation = R.attr.cardMaxElevation;
            cardPreventCornerOverlap = R.attr.cardPreventCornerOverlap;
            cardUseCompatPadding = R.attr.cardUseCompatPadding;
            cardViewStyle = R.attr.cardViewStyle;
            contentPadding = R.attr.contentPadding;
            contentPaddingBottom = R.attr.contentPaddingBottom;
            contentPaddingLeft = R.attr.contentPaddingLeft;
            contentPaddingRight = R.attr.contentPaddingRight;
            contentPaddingTop = R.attr.contentPaddingTop;
        }
    }
}
