//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package androidx.arch.core;

public final class R {
    public R() {
    }
}
