//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package androidx.activity;

public final class R {
    public R() {
    }

    public static final class styleable {
        public static final int[] ColorStateListItem;
        public static final int ColorStateListItem_alpha;
        public static final int ColorStateListItem_android_alpha;
        public static final int ColorStateListItem_android_color;
        public static final int[] FontFamily;
        public static final int FontFamily_fontProviderAuthority;
        public static final int FontFamily_fontProviderCerts;
        public static final int FontFamily_fontProviderFetchStrategy;
        public static final int FontFamily_fontProviderFetchTimeout;
        public static final int FontFamily_fontProviderPackage;
        public static final int FontFamily_fontProviderQuery;
        public static final int[] FontFamilyFont;
        public static final int FontFamilyFont_android_font;
        public static final int FontFamilyFont_android_fontStyle;
        public static final int FontFamilyFont_android_fontVariationSettings;
        public static final int FontFamilyFont_android_fontWeight;
        public static final int FontFamilyFont_android_ttcIndex;
        public static final int FontFamilyFont_font;
        public static final int FontFamilyFont_fontStyle;
        public static final int FontFamilyFont_fontVariationSettings;
        public static final int FontFamilyFont_fontWeight;
        public static final int FontFamilyFont_ttcIndex;
        public static final int[] GradientColor;
        public static final int GradientColor_android_centerColor;
        public static final int GradientColor_android_centerX;
        public static final int GradientColor_android_centerY;
        public static final int GradientColor_android_endColor;
        public static final int GradientColor_android_endX;
        public static final int GradientColor_android_endY;
        public static final int GradientColor_android_gradientRadius;
        public static final int GradientColor_android_startColor;
        public static final int GradientColor_android_startX;
        public static final int GradientColor_android_startY;
        public static final int GradientColor_android_tileMode;
        public static final int GradientColor_android_type;
        public static final int[] GradientColorItem;
        public static final int GradientColorItem_android_color;
        public static final int GradientColorItem_android_offset;

        public styleable() {
        }

        static {
            ColorStateListItem = androidx.R.styleable.ColorStateListItem;
            ColorStateListItem_alpha = androidx.R.styleable.ColorStateListItem_alpha;
            ColorStateListItem_android_alpha = androidx.R.styleable.ColorStateListItem_android_alpha;
            ColorStateListItem_android_color = androidx.R.styleable.ColorStateListItem_android_color;
            FontFamily = androidx.R.styleable.FontFamily;
            FontFamily_fontProviderAuthority = androidx.R.styleable.FontFamily_fontProviderAuthority;
            FontFamily_fontProviderCerts = androidx.R.styleable.FontFamily_fontProviderCerts;
            FontFamily_fontProviderFetchStrategy = androidx.R.styleable.FontFamily_fontProviderFetchStrategy;
            FontFamily_fontProviderFetchTimeout = androidx.R.styleable.FontFamily_fontProviderFetchTimeout;
            FontFamily_fontProviderPackage = androidx.R.styleable.FontFamily_fontProviderPackage;
            FontFamily_fontProviderQuery = androidx.R.styleable.FontFamily_fontProviderQuery;
            FontFamilyFont = androidx.R.styleable.FontFamilyFont;
            FontFamilyFont_android_font = androidx.R.styleable.FontFamilyFont_android_font;
            FontFamilyFont_android_fontStyle = androidx.R.styleable.FontFamilyFont_android_fontStyle;
            FontFamilyFont_android_fontVariationSettings = androidx.R.styleable.FontFamilyFont_android_fontVariationSettings;
            FontFamilyFont_android_fontWeight = androidx.R.styleable.FontFamilyFont_android_fontWeight;
            FontFamilyFont_android_ttcIndex = androidx.R.styleable.FontFamilyFont_android_ttcIndex;
            FontFamilyFont_font = androidx.R.styleable.FontFamilyFont_font;
            FontFamilyFont_fontStyle = androidx.R.styleable.FontFamilyFont_fontStyle;
            FontFamilyFont_fontVariationSettings = androidx.R.styleable.FontFamilyFont_fontVariationSettings;
            FontFamilyFont_fontWeight = androidx.R.styleable.FontFamilyFont_fontWeight;
            FontFamilyFont_ttcIndex = androidx.R.styleable.FontFamilyFont_ttcIndex;
            GradientColor = androidx.R.styleable.GradientColor;
            GradientColor_android_centerColor = androidx.R.styleable.GradientColor_android_centerColor;
            GradientColor_android_centerX = androidx.R.styleable.GradientColor_android_centerX;
            GradientColor_android_centerY = androidx.R.styleable.GradientColor_android_centerY;
            GradientColor_android_endColor = androidx.R.styleable.GradientColor_android_endColor;
            GradientColor_android_endX = androidx.R.styleable.GradientColor_android_endX;
            GradientColor_android_endY = androidx.R.styleable.GradientColor_android_endY;
            GradientColor_android_gradientRadius = androidx.R.styleable.GradientColor_android_gradientRadius;
            GradientColor_android_startColor = androidx.R.styleable.GradientColor_android_startColor;
            GradientColor_android_startX = androidx.R.styleable.GradientColor_android_startX;
            GradientColor_android_startY = androidx.R.styleable.GradientColor_android_startY;
            GradientColor_android_tileMode = androidx.R.styleable.GradientColor_android_tileMode;
            GradientColor_android_type = androidx.R.styleable.GradientColor_android_type;
            GradientColorItem = androidx.R.styleable.GradientColorItem;
            GradientColorItem_android_color = androidx.R.styleable.GradientColorItem_android_color;
            GradientColorItem_android_offset = androidx.R.styleable.GradientColorItem_android_offset;
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification;
        public static final int TextAppearance_Compat_Notification_Info;
        public static final int TextAppearance_Compat_Notification_Line2;
        public static final int TextAppearance_Compat_Notification_Time;
        public static final int TextAppearance_Compat_Notification_Title;
        public static final int Widget_Compat_NotificationActionContainer;
        public static final int Widget_Compat_NotificationActionText;

        public style() {
        }

        static {
            TextAppearance_Compat_Notification = androidx.R.style.TextAppearance_Compat_Notification;
            TextAppearance_Compat_Notification_Info = androidx.R.style.TextAppearance_Compat_Notification_Info;
            TextAppearance_Compat_Notification_Line2 = androidx.R.style.TextAppearance_Compat_Notification_Line2;
            TextAppearance_Compat_Notification_Time = androidx.R.style.TextAppearance_Compat_Notification_Time;
            TextAppearance_Compat_Notification_Title = androidx.R.style.TextAppearance_Compat_Notification_Title;
            Widget_Compat_NotificationActionContainer = androidx.R.style.Widget_Compat_NotificationActionContainer;
            Widget_Compat_NotificationActionText = androidx.R.style.Widget_Compat_NotificationActionText;
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow;

        public string() {
        }

        static {
            status_bar_notification_info_overflow = androidx.R.string.status_bar_notification_info_overflow;
        }
    }

    public static final class layout {
        public static final int custom_dialog;
        public static final int notification_action;
        public static final int notification_action_tombstone;
        public static final int notification_template_custom_big;
        public static final int notification_template_icon_group;
        public static final int notification_template_part_chronometer;
        public static final int notification_template_part_time;

        public layout() {
        }

        static {
            custom_dialog = androidx.R.layout.custom_dialog;
            notification_action = androidx.R.layout.notification_action;
            notification_action_tombstone = androidx.R.layout.notification_action_tombstone;
            notification_template_custom_big = androidx.R.layout.notification_template_custom_big;
            notification_template_icon_group = androidx.R.layout.notification_template_icon_group;
            notification_template_part_chronometer = androidx.R.layout.notification_template_part_chronometer;
            notification_template_part_time = androidx.R.layout.notification_template_part_time;
        }
    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum;

        public integer() {
        }

        static {
            status_bar_notification_info_maxnum = androidx.R.integer.status_bar_notification_info_maxnum;
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span;
        public static final int accessibility_custom_action_0;
        public static final int accessibility_custom_action_1;
        public static final int accessibility_custom_action_10;
        public static final int accessibility_custom_action_11;
        public static final int accessibility_custom_action_12;
        public static final int accessibility_custom_action_13;
        public static final int accessibility_custom_action_14;
        public static final int accessibility_custom_action_15;
        public static final int accessibility_custom_action_16;
        public static final int accessibility_custom_action_17;
        public static final int accessibility_custom_action_18;
        public static final int accessibility_custom_action_19;
        public static final int accessibility_custom_action_2;
        public static final int accessibility_custom_action_20;
        public static final int accessibility_custom_action_21;
        public static final int accessibility_custom_action_22;
        public static final int accessibility_custom_action_23;
        public static final int accessibility_custom_action_24;
        public static final int accessibility_custom_action_25;
        public static final int accessibility_custom_action_26;
        public static final int accessibility_custom_action_27;
        public static final int accessibility_custom_action_28;
        public static final int accessibility_custom_action_29;
        public static final int accessibility_custom_action_3;
        public static final int accessibility_custom_action_30;
        public static final int accessibility_custom_action_31;
        public static final int accessibility_custom_action_4;
        public static final int accessibility_custom_action_5;
        public static final int accessibility_custom_action_6;
        public static final int accessibility_custom_action_7;
        public static final int accessibility_custom_action_8;
        public static final int accessibility_custom_action_9;
        public static final int action_container;
        public static final int action_divider;
        public static final int action_image;
        public static final int action_text;
        public static final int actions;
        public static final int async;
        public static final int blocking;
        public static final int chronometer;
        public static final int dialog_button;
        public static final int forever;
        public static final int icon;
        public static final int icon_group;
        public static final int info;
        public static final int italic;
        public static final int line1;
        public static final int line3;
        public static final int normal;
        public static final int notification_background;
        public static final int notification_main_column;
        public static final int notification_main_column_container;
        public static final int right_icon;
        public static final int right_side;
        public static final int tag_accessibility_actions;
        public static final int tag_accessibility_clickable_spans;
        public static final int tag_accessibility_heading;
        public static final int tag_accessibility_pane_title;
        public static final int tag_screen_reader_focusable;
        public static final int tag_transition_group;
        public static final int tag_unhandled_key_event_manager;
        public static final int tag_unhandled_key_listeners;
        public static final int text;
        public static final int text2;
        public static final int time;
        public static final int title;

        public id() {
        }

        static {
            accessibility_action_clickable_span = androidx.R.id.accessibility_action_clickable_span;
            accessibility_custom_action_0 = androidx.R.id.accessibility_custom_action_0;
            accessibility_custom_action_1 = androidx.R.id.accessibility_custom_action_1;
            accessibility_custom_action_10 = androidx.R.id.accessibility_custom_action_10;
            accessibility_custom_action_11 = androidx.R.id.accessibility_custom_action_11;
            accessibility_custom_action_12 = androidx.R.id.accessibility_custom_action_12;
            accessibility_custom_action_13 = androidx.R.id.accessibility_custom_action_13;
            accessibility_custom_action_14 = androidx.R.id.accessibility_custom_action_14;
            accessibility_custom_action_15 = androidx.R.id.accessibility_custom_action_15;
            accessibility_custom_action_16 = androidx.R.id.accessibility_custom_action_16;
            accessibility_custom_action_17 = androidx.R.id.accessibility_custom_action_17;
            accessibility_custom_action_18 = androidx.R.id.accessibility_custom_action_18;
            accessibility_custom_action_19 = androidx.R.id.accessibility_custom_action_19;
            accessibility_custom_action_2 = androidx.R.id.accessibility_custom_action_2;
            accessibility_custom_action_20 = androidx.R.id.accessibility_custom_action_20;
            accessibility_custom_action_21 = androidx.R.id.accessibility_custom_action_21;
            accessibility_custom_action_22 = androidx.R.id.accessibility_custom_action_22;
            accessibility_custom_action_23 = androidx.R.id.accessibility_custom_action_23;
            accessibility_custom_action_24 = androidx.R.id.accessibility_custom_action_24;
            accessibility_custom_action_25 = androidx.R.id.accessibility_custom_action_25;
            accessibility_custom_action_26 = androidx.R.id.accessibility_custom_action_26;
            accessibility_custom_action_27 = androidx.R.id.accessibility_custom_action_27;
            accessibility_custom_action_28 = androidx.R.id.accessibility_custom_action_28;
            accessibility_custom_action_29 = androidx.R.id.accessibility_custom_action_29;
            accessibility_custom_action_3 = androidx.R.id.accessibility_custom_action_3;
            accessibility_custom_action_30 = androidx.R.id.accessibility_custom_action_30;
            accessibility_custom_action_31 = androidx.R.id.accessibility_custom_action_31;
            accessibility_custom_action_4 = androidx.R.id.accessibility_custom_action_4;
            accessibility_custom_action_5 = androidx.R.id.accessibility_custom_action_5;
            accessibility_custom_action_6 = androidx.R.id.accessibility_custom_action_6;
            accessibility_custom_action_7 = androidx.R.id.accessibility_custom_action_7;
            accessibility_custom_action_8 = androidx.R.id.accessibility_custom_action_8;
            accessibility_custom_action_9 = androidx.R.id.accessibility_custom_action_9;
            action_container = androidx.R.id.action_container;
            action_divider = androidx.R.id.action_divider;
            action_image = androidx.R.id.action_image;
            action_text = androidx.R.id.action_text;
            actions = androidx.R.id.actions;
            async = androidx.R.id.async;
            blocking = androidx.R.id.blocking;
            chronometer = androidx.R.id.chronometer;
            dialog_button = androidx.R.id.dialog_button;
            forever = androidx.R.id.forever;
            icon = androidx.R.id.icon;
            icon_group = androidx.R.id.icon_group;
            info = androidx.R.id.info;
            italic = androidx.R.id.italic;
            line1 = androidx.R.id.line1;
            line3 = androidx.R.id.line3;
            normal = androidx.R.id.normal;
            notification_background = androidx.R.id.notification_background;
            notification_main_column = androidx.R.id.notification_main_column;
            notification_main_column_container = androidx.R.id.notification_main_column_container;
            right_icon = androidx.R.id.right_icon;
            right_side = androidx.R.id.right_side;
            tag_accessibility_actions = androidx.R.id.tag_accessibility_actions;
            tag_accessibility_clickable_spans = androidx.R.id.tag_accessibility_clickable_spans;
            tag_accessibility_heading = androidx.R.id.tag_accessibility_heading;
            tag_accessibility_pane_title = androidx.R.id.tag_accessibility_pane_title;
            tag_screen_reader_focusable = androidx.R.id.tag_screen_reader_focusable;
            tag_transition_group = androidx.R.id.tag_transition_group;
            tag_unhandled_key_event_manager = androidx.R.id.tag_unhandled_key_event_manager;
            tag_unhandled_key_listeners = androidx.R.id.tag_unhandled_key_listeners;
            text = androidx.R.id.text;
            text2 = androidx.R.id.text2;
            time = androidx.R.id.time;
            title = androidx.R.id.title;
        }
    }

    public static final class drawable {
        public static final int notification_action_background;
        public static final int notification_bg;
        public static final int notification_bg_low;
        public static final int notification_bg_low_normal;
        public static final int notification_bg_low_pressed;
        public static final int notification_bg_normal;
        public static final int notification_bg_normal_pressed;
        public static final int notification_icon_background;
        public static final int notification_template_icon_bg;
        public static final int notification_template_icon_low_bg;
        public static final int notification_tile_bg;
        public static final int notify_panel_notification_icon_bg;

        public drawable() {
        }

        static {
            notification_action_background = androidx.R.drawable.notification_action_background;
            notification_bg = androidx.R.drawable.notification_bg;
            notification_bg_low = androidx.R.drawable.notification_bg_low;
            notification_bg_low_normal = androidx.R.drawable.notification_bg_low_normal;
            notification_bg_low_pressed = androidx.R.drawable.notification_bg_low_pressed;
            notification_bg_normal = androidx.R.drawable.notification_bg_normal;
            notification_bg_normal_pressed = androidx.R.drawable.notification_bg_normal_pressed;
            notification_icon_background = androidx.R.drawable.notification_icon_background;
            notification_template_icon_bg = androidx.R.drawable.notification_template_icon_bg;
            notification_template_icon_low_bg = androidx.R.drawable.notification_template_icon_low_bg;
            notification_tile_bg = androidx.R.drawable.notification_tile_bg;
            notify_panel_notification_icon_bg = androidx.R.drawable.notify_panel_notification_icon_bg;
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material;
        public static final int compat_button_inset_vertical_material;
        public static final int compat_button_padding_horizontal_material;
        public static final int compat_button_padding_vertical_material;
        public static final int compat_control_corner_material;
        public static final int compat_notification_large_icon_max_height;
        public static final int compat_notification_large_icon_max_width;
        public static final int notification_action_icon_size;
        public static final int notification_action_text_size;
        public static final int notification_big_circle_margin;
        public static final int notification_content_margin_start;
        public static final int notification_large_icon_height;
        public static final int notification_large_icon_width;
        public static final int notification_main_column_padding_top;
        public static final int notification_media_narrow_margin;
        public static final int notification_right_icon_size;
        public static final int notification_right_side_padding_top;
        public static final int notification_small_icon_background_padding;
        public static final int notification_small_icon_size_as_large;
        public static final int notification_subtext_size;
        public static final int notification_top_pad;
        public static final int notification_top_pad_large_text;

        public dimen() {
        }

        static {
            compat_button_inset_horizontal_material = androidx.R.dimen.compat_button_inset_horizontal_material;
            compat_button_inset_vertical_material = androidx.R.dimen.compat_button_inset_vertical_material;
            compat_button_padding_horizontal_material = androidx.R.dimen.compat_button_padding_horizontal_material;
            compat_button_padding_vertical_material = androidx.R.dimen.compat_button_padding_vertical_material;
            compat_control_corner_material = androidx.R.dimen.compat_control_corner_material;
            compat_notification_large_icon_max_height = androidx.R.dimen.compat_notification_large_icon_max_height;
            compat_notification_large_icon_max_width = androidx.R.dimen.compat_notification_large_icon_max_width;
            notification_action_icon_size = androidx.R.dimen.notification_action_icon_size;
            notification_action_text_size = androidx.R.dimen.notification_action_text_size;
            notification_big_circle_margin = androidx.R.dimen.notification_big_circle_margin;
            notification_content_margin_start = androidx.R.dimen.notification_content_margin_start;
            notification_large_icon_height = androidx.R.dimen.notification_large_icon_height;
            notification_large_icon_width = androidx.R.dimen.notification_large_icon_width;
            notification_main_column_padding_top = androidx.R.dimen.notification_main_column_padding_top;
            notification_media_narrow_margin = androidx.R.dimen.notification_media_narrow_margin;
            notification_right_icon_size = androidx.R.dimen.notification_right_icon_size;
            notification_right_side_padding_top = androidx.R.dimen.notification_right_side_padding_top;
            notification_small_icon_background_padding = androidx.R.dimen.notification_small_icon_background_padding;
            notification_small_icon_size_as_large = androidx.R.dimen.notification_small_icon_size_as_large;
            notification_subtext_size = androidx.R.dimen.notification_subtext_size;
            notification_top_pad = androidx.R.dimen.notification_top_pad;
            notification_top_pad_large_text = androidx.R.dimen.notification_top_pad_large_text;
        }
    }

    public static final class color {
        public static final int notification_action_color_filter;
        public static final int notification_icon_bg_color;
        public static final int ripple_material_light;
        public static final int secondary_text_default_material_light;

        public color() {
        }

        static {
            notification_action_color_filter = androidx.R.color.notification_action_color_filter;
            notification_icon_bg_color = androidx.R.color.notification_icon_bg_color;
            ripple_material_light = androidx.R.color.ripple_material_light;
            secondary_text_default_material_light = androidx.R.color.secondary_text_default_material_light;
        }
    }

    public static final class attr {
        public static final int alpha;
        public static final int font;
        public static final int fontProviderAuthority;
        public static final int fontProviderCerts;
        public static final int fontProviderFetchStrategy;
        public static final int fontProviderFetchTimeout;
        public static final int fontProviderPackage;
        public static final int fontProviderQuery;
        public static final int fontStyle;
        public static final int fontVariationSettings;
        public static final int fontWeight;
        public static final int ttcIndex;

        public attr() {
        }

        static {
            alpha = androidx.R.attr.alpha;
            font = androidx.R.attr.font;
            fontProviderAuthority = androidx.R.attr.fontProviderAuthority;
            fontProviderCerts = androidx.R.attr.fontProviderCerts;
            fontProviderFetchStrategy = androidx.R.attr.fontProviderFetchStrategy;
            fontProviderFetchTimeout = androidx.R.attr.fontProviderFetchTimeout;
            fontProviderPackage = androidx.R.attr.fontProviderPackage;
            fontProviderQuery = androidx.R.attr.fontProviderQuery;
            fontStyle = androidx.R.attr.fontStyle;
            fontVariationSettings = androidx.R.attr.fontVariationSettings;
            fontWeight = androidx.R.attr.fontWeight;
            ttcIndex = androidx.R.attr.ttcIndex;
        }
    }
}
