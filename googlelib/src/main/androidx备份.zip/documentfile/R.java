//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package androidx.documentfile;

public final class R {
    public R() {
    }
}