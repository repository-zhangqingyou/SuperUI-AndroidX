//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package android.arch.lifecycle;

public final class R {
    public R() {
    }
}