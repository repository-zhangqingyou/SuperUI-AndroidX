//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package androidx.coordinatorlayout;

public final class R {
    public R() {
    }

    public static final class styleable {
        public static final int[] ColorStateListItem;
        public static final int ColorStateListItem_alpha;
        public static final int ColorStateListItem_android_alpha;
        public static final int ColorStateListItem_android_color;
        public static final int[] CoordinatorLayout;
        public static final int CoordinatorLayout_keylines;
        public static final int CoordinatorLayout_statusBarBackground;
        public static final int[] CoordinatorLayout_Layout;
        public static final int CoordinatorLayout_Layout_android_layout_gravity;
        public static final int CoordinatorLayout_Layout_layout_anchor;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity;
        public static final int CoordinatorLayout_Layout_layout_behavior;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges;
        public static final int CoordinatorLayout_Layout_layout_insetEdge;
        public static final int CoordinatorLayout_Layout_layout_keyline;
        public static final int[] FontFamily;
        public static final int FontFamily_fontProviderAuthority;
        public static final int FontFamily_fontProviderCerts;
        public static final int FontFamily_fontProviderFetchStrategy;
        public static final int FontFamily_fontProviderFetchTimeout;
        public static final int FontFamily_fontProviderPackage;
        public static final int FontFamily_fontProviderQuery;
        public static final int[] FontFamilyFont;
        public static final int FontFamilyFont_android_font;
        public static final int FontFamilyFont_android_fontStyle;
        public static final int FontFamilyFont_android_fontVariationSettings;
        public static final int FontFamilyFont_android_fontWeight;
        public static final int FontFamilyFont_android_ttcIndex;
        public static final int FontFamilyFont_font;
        public static final int FontFamilyFont_fontStyle;
        public static final int FontFamilyFont_fontVariationSettings;
        public static final int FontFamilyFont_fontWeight;
        public static final int FontFamilyFont_ttcIndex;
        public static final int[] GradientColor;
        public static final int GradientColor_android_centerColor;
        public static final int GradientColor_android_centerX;
        public static final int GradientColor_android_centerY;
        public static final int GradientColor_android_endColor;
        public static final int GradientColor_android_endX;
        public static final int GradientColor_android_endY;
        public static final int GradientColor_android_gradientRadius;
        public static final int GradientColor_android_startColor;
        public static final int GradientColor_android_startX;
        public static final int GradientColor_android_startY;
        public static final int GradientColor_android_tileMode;
        public static final int GradientColor_android_type;
        public static final int[] GradientColorItem;
        public static final int GradientColorItem_android_color;
        public static final int GradientColorItem_android_offset;

        public styleable() {
        }

        static {
            ColorStateListItem = com.zqy.nt.sui.R.styleable.ColorStateListItem;
            ColorStateListItem_alpha = com.zqy.nt.sui.R.styleable.ColorStateListItem_alpha;
            ColorStateListItem_android_alpha = com.zqy.nt.sui.R.styleable.ColorStateListItem_android_alpha;
            ColorStateListItem_android_color = com.zqy.nt.sui.R.styleable.ColorStateListItem_android_color;
            CoordinatorLayout = com.zqy.nt.sui.R.styleable.CoordinatorLayout;
            CoordinatorLayout_keylines = com.zqy.nt.sui.R.styleable.CoordinatorLayout_keylines;
            CoordinatorLayout_statusBarBackground = com.zqy.nt.sui.R.styleable.CoordinatorLayout_statusBarBackground;
            CoordinatorLayout_Layout = com.zqy.nt.sui.R.styleable.CoordinatorLayout_Layout;
            CoordinatorLayout_Layout_android_layout_gravity = com.zqy.nt.sui.R.styleable.CoordinatorLayout_Layout_android_layout_gravity;
            CoordinatorLayout_Layout_layout_anchor = com.zqy.nt.sui.R.styleable.CoordinatorLayout_Layout_layout_anchor;
            CoordinatorLayout_Layout_layout_anchorGravity = com.zqy.nt.sui.R.styleable.CoordinatorLayout_Layout_layout_anchorGravity;
            CoordinatorLayout_Layout_layout_behavior = com.zqy.nt.sui.R.styleable.CoordinatorLayout_Layout_layout_behavior;
            CoordinatorLayout_Layout_layout_dodgeInsetEdges = com.zqy.nt.sui.R.styleable.CoordinatorLayout_Layout_layout_dodgeInsetEdges;
            CoordinatorLayout_Layout_layout_insetEdge = com.zqy.nt.sui.R.styleable.CoordinatorLayout_Layout_layout_insetEdge;
            CoordinatorLayout_Layout_layout_keyline = com.zqy.nt.sui.R.styleable.CoordinatorLayout_Layout_layout_keyline;
            FontFamily = com.zqy.nt.sui.R.styleable.FontFamily;
            FontFamily_fontProviderAuthority = com.zqy.nt.sui.R.styleable.FontFamily_fontProviderAuthority;
            FontFamily_fontProviderCerts = com.zqy.nt.sui.R.styleable.FontFamily_fontProviderCerts;
            FontFamily_fontProviderFetchStrategy = com.zqy.nt.sui.R.styleable.FontFamily_fontProviderFetchStrategy;
            FontFamily_fontProviderFetchTimeout = com.zqy.nt.sui.R.styleable.FontFamily_fontProviderFetchTimeout;
            FontFamily_fontProviderPackage = com.zqy.nt.sui.R.styleable.FontFamily_fontProviderPackage;
            FontFamily_fontProviderQuery = com.zqy.nt.sui.R.styleable.FontFamily_fontProviderQuery;
            FontFamilyFont = com.zqy.nt.sui.R.styleable.FontFamilyFont;
            FontFamilyFont_android_font = com.zqy.nt.sui.R.styleable.FontFamilyFont_android_font;
            FontFamilyFont_android_fontStyle = com.zqy.nt.sui.R.styleable.FontFamilyFont_android_fontStyle;
            FontFamilyFont_android_fontVariationSettings = com.zqy.nt.sui.R.styleable.FontFamilyFont_android_fontVariationSettings;
            FontFamilyFont_android_fontWeight = com.zqy.nt.sui.R.styleable.FontFamilyFont_android_fontWeight;
            FontFamilyFont_android_ttcIndex = com.zqy.nt.sui.R.styleable.FontFamilyFont_android_ttcIndex;
            FontFamilyFont_font = com.zqy.nt.sui.R.styleable.FontFamilyFont_font;
            FontFamilyFont_fontStyle = com.zqy.nt.sui.R.styleable.FontFamilyFont_fontStyle;
            FontFamilyFont_fontVariationSettings = com.zqy.nt.sui.R.styleable.FontFamilyFont_fontVariationSettings;
            FontFamilyFont_fontWeight = com.zqy.nt.sui.R.styleable.FontFamilyFont_fontWeight;
            FontFamilyFont_ttcIndex = com.zqy.nt.sui.R.styleable.FontFamilyFont_ttcIndex;
            GradientColor = com.zqy.nt.sui.R.styleable.GradientColor;
            GradientColor_android_centerColor = com.zqy.nt.sui.R.styleable.GradientColor_android_centerColor;
            GradientColor_android_centerX = com.zqy.nt.sui.R.styleable.GradientColor_android_centerX;
            GradientColor_android_centerY = com.zqy.nt.sui.R.styleable.GradientColor_android_centerY;
            GradientColor_android_endColor = com.zqy.nt.sui.R.styleable.GradientColor_android_endColor;
            GradientColor_android_endX = com.zqy.nt.sui.R.styleable.GradientColor_android_endX;
            GradientColor_android_endY = com.zqy.nt.sui.R.styleable.GradientColor_android_endY;
            GradientColor_android_gradientRadius = com.zqy.nt.sui.R.styleable.GradientColor_android_gradientRadius;
            GradientColor_android_startColor = com.zqy.nt.sui.R.styleable.GradientColor_android_startColor;
            GradientColor_android_startX = com.zqy.nt.sui.R.styleable.GradientColor_android_startX;
            GradientColor_android_startY = com.zqy.nt.sui.R.styleable.GradientColor_android_startY;
            GradientColor_android_tileMode = com.zqy.nt.sui.R.styleable.GradientColor_android_tileMode;
            GradientColor_android_type = com.zqy.nt.sui.R.styleable.GradientColor_android_type;
            GradientColorItem = com.zqy.nt.sui.R.styleable.GradientColorItem;
            GradientColorItem_android_color = com.zqy.nt.sui.R.styleable.GradientColorItem_android_color;
            GradientColorItem_android_offset = com.zqy.nt.sui.R.styleable.GradientColorItem_android_offset;
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification;
        public static final int TextAppearance_Compat_Notification_Info;
        public static final int TextAppearance_Compat_Notification_Line2;
        public static final int TextAppearance_Compat_Notification_Time;
        public static final int TextAppearance_Compat_Notification_Title;
        public static final int Widget_Compat_NotificationActionContainer;
        public static final int Widget_Compat_NotificationActionText;
        public static final int Widget_Support_CoordinatorLayout;

        public style() {
        }

        static {
            TextAppearance_Compat_Notification = com.zqy.nt.sui.R.style.TextAppearance_Compat_Notification;
            TextAppearance_Compat_Notification_Info = com.zqy.nt.sui.R.style.TextAppearance_Compat_Notification_Info;
            TextAppearance_Compat_Notification_Line2 = com.zqy.nt.sui.R.style.TextAppearance_Compat_Notification_Line2;
            TextAppearance_Compat_Notification_Time = com.zqy.nt.sui.R.style.TextAppearance_Compat_Notification_Time;
            TextAppearance_Compat_Notification_Title = com.zqy.nt.sui.R.style.TextAppearance_Compat_Notification_Title;
            Widget_Compat_NotificationActionContainer = com.zqy.nt.sui.R.style.Widget_Compat_NotificationActionContainer;
            Widget_Compat_NotificationActionText = com.zqy.nt.sui.R.style.Widget_Compat_NotificationActionText;
            Widget_Support_CoordinatorLayout = com.zqy.nt.sui.R.style.Widget_Support_CoordinatorLayout;
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow;

        public string() {
        }

        static {
            status_bar_notification_info_overflow = com.zqy.nt.sui.R.string.status_bar_notification_info_overflow;
        }
    }

    public static final class layout {
        public static final int custom_dialog;
        public static final int notification_action;
        public static final int notification_action_tombstone;
        public static final int notification_template_custom_big;
        public static final int notification_template_icon_group;
        public static final int notification_template_part_chronometer;
        public static final int notification_template_part_time;

        public layout() {
        }

        static {
            custom_dialog = com.zqy.nt.sui.R.layout.custom_dialog;
            notification_action = com.zqy.nt.sui.R.layout.notification_action;
            notification_action_tombstone = com.zqy.nt.sui.R.layout.notification_action_tombstone;
            notification_template_custom_big = com.zqy.nt.sui.R.layout.notification_template_custom_big;
            notification_template_icon_group = com.zqy.nt.sui.R.layout.notification_template_icon_group;
            notification_template_part_chronometer = com.zqy.nt.sui.R.layout.notification_template_part_chronometer;
            notification_template_part_time = com.zqy.nt.sui.R.layout.notification_template_part_time;
        }
    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum;

        public integer() {
        }

        static {
            status_bar_notification_info_maxnum = com.zqy.nt.sui.R.integer.status_bar_notification_info_maxnum;
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span;
        public static final int accessibility_custom_action_0;
        public static final int accessibility_custom_action_1;
        public static final int accessibility_custom_action_10;
        public static final int accessibility_custom_action_11;
        public static final int accessibility_custom_action_12;
        public static final int accessibility_custom_action_13;
        public static final int accessibility_custom_action_14;
        public static final int accessibility_custom_action_15;
        public static final int accessibility_custom_action_16;
        public static final int accessibility_custom_action_17;
        public static final int accessibility_custom_action_18;
        public static final int accessibility_custom_action_19;
        public static final int accessibility_custom_action_2;
        public static final int accessibility_custom_action_20;
        public static final int accessibility_custom_action_21;
        public static final int accessibility_custom_action_22;
        public static final int accessibility_custom_action_23;
        public static final int accessibility_custom_action_24;
        public static final int accessibility_custom_action_25;
        public static final int accessibility_custom_action_26;
        public static final int accessibility_custom_action_27;
        public static final int accessibility_custom_action_28;
        public static final int accessibility_custom_action_29;
        public static final int accessibility_custom_action_3;
        public static final int accessibility_custom_action_30;
        public static final int accessibility_custom_action_31;
        public static final int accessibility_custom_action_4;
        public static final int accessibility_custom_action_5;
        public static final int accessibility_custom_action_6;
        public static final int accessibility_custom_action_7;
        public static final int accessibility_custom_action_8;
        public static final int accessibility_custom_action_9;
        public static final int action_container;
        public static final int action_divider;
        public static final int action_image;
        public static final int action_text;
        public static final int actions;
        public static final int async;
        public static final int blocking;
        public static final int bottom;
        public static final int chronometer;
        public static final int dialog_button;
        public static final int end;
        public static final int forever;
        public static final int icon;
        public static final int icon_group;
        public static final int info;
        public static final int italic;
        public static final int left;
        public static final int line1;
        public static final int line3;
        public static final int none;
        public static final int normal;
        public static final int notification_background;
        public static final int notification_main_column;
        public static final int notification_main_column_container;
        public static final int right;
        public static final int right_icon;
        public static final int right_side;
        public static final int start;
        public static final int tag_accessibility_actions;
        public static final int tag_accessibility_clickable_spans;
        public static final int tag_accessibility_heading;
        public static final int tag_accessibility_pane_title;
        public static final int tag_screen_reader_focusable;
        public static final int tag_transition_group;
        public static final int tag_unhandled_key_event_manager;
        public static final int tag_unhandled_key_listeners;
        public static final int text;
        public static final int text2;
        public static final int time;
        public static final int title;
        public static final int top;

        public id() {
        }

        static {
            accessibility_action_clickable_span = com.zqy.nt.sui.R.id.accessibility_action_clickable_span;
            accessibility_custom_action_0 = com.zqy.nt.sui.R.id.accessibility_custom_action_0;
            accessibility_custom_action_1 = com.zqy.nt.sui.R.id.accessibility_custom_action_1;
            accessibility_custom_action_10 = com.zqy.nt.sui.R.id.accessibility_custom_action_10;
            accessibility_custom_action_11 = com.zqy.nt.sui.R.id.accessibility_custom_action_11;
            accessibility_custom_action_12 = com.zqy.nt.sui.R.id.accessibility_custom_action_12;
            accessibility_custom_action_13 = com.zqy.nt.sui.R.id.accessibility_custom_action_13;
            accessibility_custom_action_14 = com.zqy.nt.sui.R.id.accessibility_custom_action_14;
            accessibility_custom_action_15 = com.zqy.nt.sui.R.id.accessibility_custom_action_15;
            accessibility_custom_action_16 = com.zqy.nt.sui.R.id.accessibility_custom_action_16;
            accessibility_custom_action_17 = com.zqy.nt.sui.R.id.accessibility_custom_action_17;
            accessibility_custom_action_18 = com.zqy.nt.sui.R.id.accessibility_custom_action_18;
            accessibility_custom_action_19 = com.zqy.nt.sui.R.id.accessibility_custom_action_19;
            accessibility_custom_action_2 = com.zqy.nt.sui.R.id.accessibility_custom_action_2;
            accessibility_custom_action_20 = com.zqy.nt.sui.R.id.accessibility_custom_action_20;
            accessibility_custom_action_21 = com.zqy.nt.sui.R.id.accessibility_custom_action_21;
            accessibility_custom_action_22 = com.zqy.nt.sui.R.id.accessibility_custom_action_22;
            accessibility_custom_action_23 = com.zqy.nt.sui.R.id.accessibility_custom_action_23;
            accessibility_custom_action_24 = com.zqy.nt.sui.R.id.accessibility_custom_action_24;
            accessibility_custom_action_25 = com.zqy.nt.sui.R.id.accessibility_custom_action_25;
            accessibility_custom_action_26 = com.zqy.nt.sui.R.id.accessibility_custom_action_26;
            accessibility_custom_action_27 = com.zqy.nt.sui.R.id.accessibility_custom_action_27;
            accessibility_custom_action_28 = com.zqy.nt.sui.R.id.accessibility_custom_action_28;
            accessibility_custom_action_29 = com.zqy.nt.sui.R.id.accessibility_custom_action_29;
            accessibility_custom_action_3 = com.zqy.nt.sui.R.id.accessibility_custom_action_3;
            accessibility_custom_action_30 = com.zqy.nt.sui.R.id.accessibility_custom_action_30;
            accessibility_custom_action_31 = com.zqy.nt.sui.R.id.accessibility_custom_action_31;
            accessibility_custom_action_4 = com.zqy.nt.sui.R.id.accessibility_custom_action_4;
            accessibility_custom_action_5 = com.zqy.nt.sui.R.id.accessibility_custom_action_5;
            accessibility_custom_action_6 = com.zqy.nt.sui.R.id.accessibility_custom_action_6;
            accessibility_custom_action_7 = com.zqy.nt.sui.R.id.accessibility_custom_action_7;
            accessibility_custom_action_8 = com.zqy.nt.sui.R.id.accessibility_custom_action_8;
            accessibility_custom_action_9 = com.zqy.nt.sui.R.id.accessibility_custom_action_9;
            action_container = com.zqy.nt.sui.R.id.action_container;
            action_divider = com.zqy.nt.sui.R.id.action_divider;
            action_image = com.zqy.nt.sui.R.id.action_image;
            action_text = com.zqy.nt.sui.R.id.action_text;
            actions = com.zqy.nt.sui.R.id.actions;
            async = com.zqy.nt.sui.R.id.async;
            blocking = com.zqy.nt.sui.R.id.blocking;
            bottom = com.zqy.nt.sui.R.id.bottom;
            chronometer = com.zqy.nt.sui.R.id.chronometer;
            dialog_button = com.zqy.nt.sui.R.id.dialog_button;
            end = com.zqy.nt.sui.R.id.end;
            forever = com.zqy.nt.sui.R.id.forever;
            icon = com.zqy.nt.sui.R.id.icon;
            icon_group = com.zqy.nt.sui.R.id.icon_group;
            info = com.zqy.nt.sui.R.id.info;
            italic = com.zqy.nt.sui.R.id.italic;
            left = com.zqy.nt.sui.R.id.left;
            line1 = com.zqy.nt.sui.R.id.line1;
            line3 = com.zqy.nt.sui.R.id.line3;
            none = com.zqy.nt.sui.R.id.none;
            normal = com.zqy.nt.sui.R.id.normal;
            notification_background = com.zqy.nt.sui.R.id.notification_background;
            notification_main_column = com.zqy.nt.sui.R.id.notification_main_column;
            notification_main_column_container = com.zqy.nt.sui.R.id.notification_main_column_container;
            right = com.zqy.nt.sui.R.id.right;
            right_icon = com.zqy.nt.sui.R.id.right_icon;
            right_side = com.zqy.nt.sui.R.id.right_side;
            start = com.zqy.nt.sui.R.id.start;
            tag_accessibility_actions = com.zqy.nt.sui.R.id.tag_accessibility_actions;
            tag_accessibility_clickable_spans = com.zqy.nt.sui.R.id.tag_accessibility_clickable_spans;
            tag_accessibility_heading = com.zqy.nt.sui.R.id.tag_accessibility_heading;
            tag_accessibility_pane_title = com.zqy.nt.sui.R.id.tag_accessibility_pane_title;
            tag_screen_reader_focusable = com.zqy.nt.sui.R.id.tag_screen_reader_focusable;
            tag_transition_group = com.zqy.nt.sui.R.id.tag_transition_group;
            tag_unhandled_key_event_manager = com.zqy.nt.sui.R.id.tag_unhandled_key_event_manager;
            tag_unhandled_key_listeners = com.zqy.nt.sui.R.id.tag_unhandled_key_listeners;
            text = com.zqy.nt.sui.R.id.text;
            text2 = com.zqy.nt.sui.R.id.text2;
            time = com.zqy.nt.sui.R.id.time;
            title = com.zqy.nt.sui.R.id.title;
            top = com.zqy.nt.sui.R.id.top;
        }
    }

    public static final class drawable {
        public static final int notification_action_background;
        public static final int notification_bg;
        public static final int notification_bg_low;
        public static final int notification_bg_low_normal;
        public static final int notification_bg_low_pressed;
        public static final int notification_bg_normal;
        public static final int notification_bg_normal_pressed;
        public static final int notification_icon_background;
        public static final int notification_template_icon_bg;
        public static final int notification_template_icon_low_bg;
        public static final int notification_tile_bg;
        public static final int notify_panel_notification_icon_bg;

        public drawable() {
        }

        static {
            notification_action_background = com.zqy.nt.sui.R.drawable.notification_action_background;
            notification_bg = com.zqy.nt.sui.R.drawable.notification_bg;
            notification_bg_low = com.zqy.nt.sui.R.drawable.notification_bg_low;
            notification_bg_low_normal = com.zqy.nt.sui.R.drawable.notification_bg_low_normal;
            notification_bg_low_pressed = com.zqy.nt.sui.R.drawable.notification_bg_low_pressed;
            notification_bg_normal = com.zqy.nt.sui.R.drawable.notification_bg_normal;
            notification_bg_normal_pressed = com.zqy.nt.sui.R.drawable.notification_bg_normal_pressed;
            notification_icon_background = com.zqy.nt.sui.R.drawable.notification_icon_background;
            notification_template_icon_bg = com.zqy.nt.sui.R.drawable.notification_template_icon_bg;
            notification_template_icon_low_bg = com.zqy.nt.sui.R.drawable.notification_template_icon_low_bg;
            notification_tile_bg = com.zqy.nt.sui.R.drawable.notification_tile_bg;
            notify_panel_notification_icon_bg = com.zqy.nt.sui.R.drawable.notify_panel_notification_icon_bg;
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material;
        public static final int compat_button_inset_vertical_material;
        public static final int compat_button_padding_horizontal_material;
        public static final int compat_button_padding_vertical_material;
        public static final int compat_control_corner_material;
        public static final int compat_notification_large_icon_max_height;
        public static final int compat_notification_large_icon_max_width;
        public static final int notification_action_icon_size;
        public static final int notification_action_text_size;
        public static final int notification_big_circle_margin;
        public static final int notification_content_margin_start;
        public static final int notification_large_icon_height;
        public static final int notification_large_icon_width;
        public static final int notification_main_column_padding_top;
        public static final int notification_media_narrow_margin;
        public static final int notification_right_icon_size;
        public static final int notification_right_side_padding_top;
        public static final int notification_small_icon_background_padding;
        public static final int notification_small_icon_size_as_large;
        public static final int notification_subtext_size;
        public static final int notification_top_pad;
        public static final int notification_top_pad_large_text;

        public dimen() {
        }

        static {
            compat_button_inset_horizontal_material = com.zqy.nt.sui.R.dimen.compat_button_inset_horizontal_material;
            compat_button_inset_vertical_material = com.zqy.nt.sui.R.dimen.compat_button_inset_vertical_material;
            compat_button_padding_horizontal_material = com.zqy.nt.sui.R.dimen.compat_button_padding_horizontal_material;
            compat_button_padding_vertical_material = com.zqy.nt.sui.R.dimen.compat_button_padding_vertical_material;
            compat_control_corner_material = com.zqy.nt.sui.R.dimen.compat_control_corner_material;
            compat_notification_large_icon_max_height = com.zqy.nt.sui.R.dimen.compat_notification_large_icon_max_height;
            compat_notification_large_icon_max_width = com.zqy.nt.sui.R.dimen.compat_notification_large_icon_max_width;
            notification_action_icon_size = com.zqy.nt.sui.R.dimen.notification_action_icon_size;
            notification_action_text_size = com.zqy.nt.sui.R.dimen.notification_action_text_size;
            notification_big_circle_margin = com.zqy.nt.sui.R.dimen.notification_big_circle_margin;
            notification_content_margin_start = com.zqy.nt.sui.R.dimen.notification_content_margin_start;
            notification_large_icon_height = com.zqy.nt.sui.R.dimen.notification_large_icon_height;
            notification_large_icon_width = com.zqy.nt.sui.R.dimen.notification_large_icon_width;
            notification_main_column_padding_top = com.zqy.nt.sui.R.dimen.notification_main_column_padding_top;
            notification_media_narrow_margin = com.zqy.nt.sui.R.dimen.notification_media_narrow_margin;
            notification_right_icon_size = com.zqy.nt.sui.R.dimen.notification_right_icon_size;
            notification_right_side_padding_top = com.zqy.nt.sui.R.dimen.notification_right_side_padding_top;
            notification_small_icon_background_padding = com.zqy.nt.sui.R.dimen.notification_small_icon_background_padding;
            notification_small_icon_size_as_large = com.zqy.nt.sui.R.dimen.notification_small_icon_size_as_large;
            notification_subtext_size = com.zqy.nt.sui.R.dimen.notification_subtext_size;
            notification_top_pad = com.zqy.nt.sui.R.dimen.notification_top_pad;
            notification_top_pad_large_text = com.zqy.nt.sui.R.dimen.notification_top_pad_large_text;
        }
    }

    public static final class color {
        public static final int notification_action_color_filter;
        public static final int notification_icon_bg_color;
        public static final int ripple_material_light;
        public static final int secondary_text_default_material_light;

        public color() {
        }

        static {
            notification_action_color_filter = com.zqy.nt.sui.R.color.notification_action_color_filter;
            notification_icon_bg_color = com.zqy.nt.sui.R.color.notification_icon_bg_color;
            ripple_material_light = com.zqy.nt.sui.R.color.ripple_material_light;
            secondary_text_default_material_light = com.zqy.nt.sui.R.color.secondary_text_default_material_light;
        }
    }

    public static final class attr {
        public static final int alpha;
        public static final int coordinatorLayoutStyle;
        public static final int font;
        public static final int fontProviderAuthority;
        public static final int fontProviderCerts;
        public static final int fontProviderFetchStrategy;
        public static final int fontProviderFetchTimeout;
        public static final int fontProviderPackage;
        public static final int fontProviderQuery;
        public static final int fontStyle;
        public static final int fontVariationSettings;
        public static final int fontWeight;
        public static final int keylines;
        public static final int layout_anchor;
        public static final int layout_anchorGravity;
        public static final int layout_behavior;
        public static final int layout_dodgeInsetEdges;
        public static final int layout_insetEdge;
        public static final int layout_keyline;
        public static final int statusBarBackground;
        public static final int ttcIndex;

        public attr() {
        }

        static {
            alpha = com.zqy.nt.sui.R.attr.alpha;
            coordinatorLayoutStyle = com.zqy.nt.sui.R.attr.coordinatorLayoutStyle;
            font = com.zqy.nt.sui.R.attr.font;
            fontProviderAuthority = com.zqy.nt.sui.R.attr.fontProviderAuthority;
            fontProviderCerts = com.zqy.nt.sui.R.attr.fontProviderCerts;
            fontProviderFetchStrategy = com.zqy.nt.sui.R.attr.fontProviderFetchStrategy;
            fontProviderFetchTimeout = com.zqy.nt.sui.R.attr.fontProviderFetchTimeout;
            fontProviderPackage = com.zqy.nt.sui.R.attr.fontProviderPackage;
            fontProviderQuery = com.zqy.nt.sui.R.attr.fontProviderQuery;
            fontStyle = com.zqy.nt.sui.R.attr.fontStyle;
            fontVariationSettings = com.zqy.nt.sui.R.attr.fontVariationSettings;
            fontWeight = com.zqy.nt.sui.R.attr.fontWeight;
            keylines = com.zqy.nt.sui.R.attr.keylines;
            layout_anchor = com.zqy.nt.sui.R.attr.layout_anchor;
            layout_anchorGravity = com.zqy.nt.sui.R.attr.layout_anchorGravity;
            layout_behavior = com.zqy.nt.sui.R.attr.layout_behavior;
            layout_dodgeInsetEdges = com.zqy.nt.sui.R.attr.layout_dodgeInsetEdges;
            layout_insetEdge = com.zqy.nt.sui.R.attr.layout_insetEdge;
            layout_keyline = com.zqy.nt.sui.R.attr.layout_keyline;
            statusBarBackground = com.zqy.nt.sui.R.attr.statusBarBackground;
            ttcIndex = com.zqy.nt.sui.R.attr.ttcIndex;
        }
    }
}
