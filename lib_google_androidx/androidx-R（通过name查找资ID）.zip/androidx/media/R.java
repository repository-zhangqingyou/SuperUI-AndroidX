//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package androidx.media;

public final class R {
    public R() {
    }

    public static final class styleable {
        public static final int[] ColorStateListItem;
        public static final int ColorStateListItem_alpha;
        public static final int ColorStateListItem_android_alpha;
        public static final int ColorStateListItem_android_color;
        public static final int[] FontFamily;
        public static final int FontFamily_fontProviderAuthority;
        public static final int FontFamily_fontProviderCerts;
        public static final int FontFamily_fontProviderFetchStrategy;
        public static final int FontFamily_fontProviderFetchTimeout;
        public static final int FontFamily_fontProviderPackage;
        public static final int FontFamily_fontProviderQuery;
        public static final int[] FontFamilyFont;
        public static final int FontFamilyFont_android_font;
        public static final int FontFamilyFont_android_fontStyle;
        public static final int FontFamilyFont_android_fontVariationSettings;
        public static final int FontFamilyFont_android_fontWeight;
        public static final int FontFamilyFont_android_ttcIndex;
        public static final int FontFamilyFont_font;
        public static final int FontFamilyFont_fontStyle;
        public static final int FontFamilyFont_fontVariationSettings;
        public static final int FontFamilyFont_fontWeight;
        public static final int FontFamilyFont_ttcIndex;
        public static final int[] GradientColor;
        public static final int GradientColor_android_centerColor;
        public static final int GradientColor_android_centerX;
        public static final int GradientColor_android_centerY;
        public static final int GradientColor_android_endColor;
        public static final int GradientColor_android_endX;
        public static final int GradientColor_android_endY;
        public static final int GradientColor_android_gradientRadius;
        public static final int GradientColor_android_startColor;
        public static final int GradientColor_android_startX;
        public static final int GradientColor_android_startY;
        public static final int GradientColor_android_tileMode;
        public static final int GradientColor_android_type;
        public static final int[] GradientColorItem;
        public static final int GradientColorItem_android_color;
        public static final int GradientColorItem_android_offset;

        public styleable() {
        }

        static {
            ColorStateListItem = com.zqy.googlelib.StyleaUtils.getStyleableArryId("ColorStateListItem");
            ColorStateListItem_alpha = com.zqy.googlelib.StyleaUtils.getStyleableId("ColorStateListItem_alpha");
            ColorStateListItem_android_alpha = com.zqy.googlelib.StyleaUtils.getStyleableId("ColorStateListItem_android_alpha");
            ColorStateListItem_android_color = com.zqy.googlelib.StyleaUtils.getStyleableId("ColorStateListItem_android_color");
            FontFamily = com.zqy.googlelib.StyleaUtils.getStyleableArryId("FontFamily");
            FontFamily_fontProviderAuthority = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamily_fontProviderAuthority");
            FontFamily_fontProviderCerts = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamily_fontProviderCerts");
            FontFamily_fontProviderFetchStrategy = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamily_fontProviderFetchStrategy");
            FontFamily_fontProviderFetchTimeout = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamily_fontProviderFetchTimeout");
            FontFamily_fontProviderPackage = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamily_fontProviderPackage");
            FontFamily_fontProviderQuery = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamily_fontProviderQuery");
            FontFamilyFont = com.zqy.googlelib.StyleaUtils.getStyleableArryId("FontFamilyFont");
            FontFamilyFont_android_font = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_android_font");
            FontFamilyFont_android_fontStyle = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_android_fontStyle");
            FontFamilyFont_android_fontVariationSettings = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_android_fontVariationSettings");
            FontFamilyFont_android_fontWeight = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_android_fontWeight");
            FontFamilyFont_android_ttcIndex = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_android_ttcIndex");
            FontFamilyFont_font = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_font");
            FontFamilyFont_fontStyle = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_fontStyle");
            FontFamilyFont_fontVariationSettings = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_fontVariationSettings");
            FontFamilyFont_fontWeight = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_fontWeight");
            FontFamilyFont_ttcIndex = com.zqy.googlelib.StyleaUtils.getStyleableId("FontFamilyFont_ttcIndex");
            GradientColor = com.zqy.googlelib.StyleaUtils.getStyleableArryId("GradientColor");
            GradientColor_android_centerColor = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_centerColor");
            GradientColor_android_centerX = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_centerX");
            GradientColor_android_centerY = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_centerY");
            GradientColor_android_endColor = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_endColor");
            GradientColor_android_endX = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_endX");
            GradientColor_android_endY = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_endY");
            GradientColor_android_gradientRadius = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_gradientRadius");
            GradientColor_android_startColor = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_startColor");
            GradientColor_android_startX = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_startX");
            GradientColor_android_startY = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_startY");
            GradientColor_android_tileMode = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_tileMode");
            GradientColor_android_type = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColor_android_type");
            GradientColorItem = com.zqy.googlelib.StyleaUtils.getStyleableArryId("GradientColorItem");
            GradientColorItem_android_color = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColorItem_android_color");
            GradientColorItem_android_offset = com.zqy.googlelib.StyleaUtils.getStyleableId("GradientColorItem_android_offset");
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification;
        public static final int TextAppearance_Compat_Notification_Info;
        public static final int TextAppearance_Compat_Notification_Info_Media;
        public static final int TextAppearance_Compat_Notification_Line2;
        public static final int TextAppearance_Compat_Notification_Line2_Media;
        public static final int TextAppearance_Compat_Notification_Media;
        public static final int TextAppearance_Compat_Notification_Time;
        public static final int TextAppearance_Compat_Notification_Time_Media;
        public static final int TextAppearance_Compat_Notification_Title;
        public static final int TextAppearance_Compat_Notification_Title_Media;
        public static final int Widget_Compat_NotificationActionContainer;
        public static final int Widget_Compat_NotificationActionText;

        public style() {
        }

        static {
            TextAppearance_Compat_Notification = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification");
            TextAppearance_Compat_Notification_Info = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification.Info");
            TextAppearance_Compat_Notification_Info_Media = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification.Info.Media");
            TextAppearance_Compat_Notification_Line2 = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification.Line2");
            TextAppearance_Compat_Notification_Line2_Media = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification.Line2.Media");
            TextAppearance_Compat_Notification_Media = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification.Media");
            TextAppearance_Compat_Notification_Time = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification.Time");
            TextAppearance_Compat_Notification_Time_Media = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification.Time.Media");
            TextAppearance_Compat_Notification_Title = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification.Title");
            TextAppearance_Compat_Notification_Title_Media = com.zqy.googlelib.ResourcesUtil.getStyleId("TextAppearance.Compat.Notification.Title.Media");
            Widget_Compat_NotificationActionContainer = com.zqy.googlelib.ResourcesUtil.getStyleId("Widget.Compat.NotificationActionContainer");
            Widget_Compat_NotificationActionText = com.zqy.googlelib.ResourcesUtil.getStyleId("Widget.Compat.NotificationActionText");
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow;

        public string() {
        }

        static {
            status_bar_notification_info_overflow = com.zqy.googlelib.ResourcesUtil.getStringId("status_bar_notification_info_overflow");
        }
    }

    public static final class layout {
        public static final int notification_action;
        public static final int notification_action_tombstone;
        public static final int notification_media_action;
        public static final int notification_media_cancel_action;
        public static final int notification_template_big_media;
        public static final int notification_template_big_media_custom;
        public static final int notification_template_big_media_narrow;
        public static final int notification_template_big_media_narrow_custom;
        public static final int notification_template_custom_big;
        public static final int notification_template_icon_group;
        public static final int notification_template_lines_media;
        public static final int notification_template_media;
        public static final int notification_template_media_custom;
        public static final int notification_template_part_chronometer;
        public static final int notification_template_part_time;

        public layout() {
        }

        static {
            notification_action = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_action");
            notification_action_tombstone = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_action_tombstone");
            notification_media_action = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_media_action");
            notification_media_cancel_action = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_media_cancel_action");
            notification_template_big_media = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_big_media");
            notification_template_big_media_custom = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_big_media_custom");
            notification_template_big_media_narrow = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_big_media_narrow");
            notification_template_big_media_narrow_custom = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_big_media_narrow_custom");
            notification_template_custom_big = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_custom_big");
            notification_template_icon_group = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_icon_group");
            notification_template_lines_media = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_lines_media");
            notification_template_media = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_media");
            notification_template_media_custom = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_media_custom");
            notification_template_part_chronometer = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_part_chronometer");
            notification_template_part_time = com.zqy.googlelib.ResourcesUtil.getLayoutId("notification_template_part_time");
        }
    }

    public static final class integer {
        public static final int cancel_button_image_alpha;
        public static final int status_bar_notification_info_maxnum;

        public integer() {
        }

        static {
            cancel_button_image_alpha = com.zqy.googlelib.ResourcesUtil.getInteger("cancel_button_image_alpha");
            status_bar_notification_info_maxnum = com.zqy.googlelib.ResourcesUtil.getInteger("status_bar_notification_info_maxnum");
        }
    }

    public static final class id {
        public static final int action0;
        public static final int action_container;
        public static final int action_divider;
        public static final int action_image;
        public static final int action_text;
        public static final int actions;
        public static final int async;
        public static final int blocking;
        public static final int cancel_action;
        public static final int chronometer;
        public static final int end_padder;
        public static final int forever;
        public static final int icon;
        public static final int icon_group;
        public static final int info;
        public static final int italic;
        public static final int line1;
        public static final int line3;
        public static final int media_actions;
        public static final int normal;
        public static final int notification_background;
        public static final int notification_main_column;
        public static final int notification_main_column_container;
        public static final int right_icon;
        public static final int right_side;
        public static final int status_bar_latest_event_content;
        public static final int tag_transition_group;
        public static final int tag_unhandled_key_event_manager;
        public static final int tag_unhandled_key_listeners;
        public static final int text;
        public static final int text2;
        public static final int time;
        public static final int title;

        public id() {
        }

        static {
            action0 = com.zqy.googlelib.ResourcesUtil.getId("action0");
            action_container = com.zqy.googlelib.ResourcesUtil.getId("action_container");
            action_divider = com.zqy.googlelib.ResourcesUtil.getId("action_divider");
            action_image = com.zqy.googlelib.ResourcesUtil.getId("action_image");
            action_text = com.zqy.googlelib.ResourcesUtil.getId("action_text");
            actions = com.zqy.googlelib.ResourcesUtil.getId("actions");
            async = com.zqy.googlelib.ResourcesUtil.getId("async");
            blocking = com.zqy.googlelib.ResourcesUtil.getId("blocking");
            cancel_action = com.zqy.googlelib.ResourcesUtil.getId("cancel_action");
            chronometer = com.zqy.googlelib.ResourcesUtil.getId("chronometer");
            end_padder = com.zqy.googlelib.ResourcesUtil.getId("end_padder");
            forever = com.zqy.googlelib.ResourcesUtil.getId("forever");
            icon = com.zqy.googlelib.ResourcesUtil.getId("icon");
            icon_group = com.zqy.googlelib.ResourcesUtil.getId("icon_group");
            info = com.zqy.googlelib.ResourcesUtil.getId("info");
            italic = com.zqy.googlelib.ResourcesUtil.getId("italic");
            line1 = com.zqy.googlelib.ResourcesUtil.getId("line1");
            line3 = com.zqy.googlelib.ResourcesUtil.getId("line3");
            media_actions = com.zqy.googlelib.ResourcesUtil.getId("media_actions");
            normal = com.zqy.googlelib.ResourcesUtil.getId("normal");
            notification_background = com.zqy.googlelib.ResourcesUtil.getId("notification_background");
            notification_main_column = com.zqy.googlelib.ResourcesUtil.getId("notification_main_column");
            notification_main_column_container = com.zqy.googlelib.ResourcesUtil.getId("notification_main_column_container");
            right_icon = com.zqy.googlelib.ResourcesUtil.getId("right_icon");
            right_side = com.zqy.googlelib.ResourcesUtil.getId("right_side");
            status_bar_latest_event_content = com.zqy.googlelib.ResourcesUtil.getId("status_bar_latest_event_content");
            tag_transition_group = com.zqy.googlelib.ResourcesUtil.getId("tag_transition_group");
            tag_unhandled_key_event_manager = com.zqy.googlelib.ResourcesUtil.getId("tag_unhandled_key_event_manager");
            tag_unhandled_key_listeners = com.zqy.googlelib.ResourcesUtil.getId("tag_unhandled_key_listeners");
            text = com.zqy.googlelib.ResourcesUtil.getId("text");
            text2 = com.zqy.googlelib.ResourcesUtil.getId("text2");
            time = com.zqy.googlelib.ResourcesUtil.getId("time");
            title = com.zqy.googlelib.ResourcesUtil.getId("title");
        }
    }

    public static final class drawable {
        public static final int notification_action_background;
        public static final int notification_bg;
        public static final int notification_bg_low;
        public static final int notification_bg_low_normal;
        public static final int notification_bg_low_pressed;
        public static final int notification_bg_normal;
        public static final int notification_bg_normal_pressed;
        public static final int notification_icon_background;
        public static final int notification_template_icon_bg;
        public static final int notification_template_icon_low_bg;
        public static final int notification_tile_bg;
        public static final int notify_panel_notification_icon_bg;

        public drawable() {
        }

        static {
            notification_action_background = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_action_background");
            notification_bg = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_bg");
            notification_bg_low = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_bg_low");
            notification_bg_low_normal = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_bg_low_normal");
            notification_bg_low_pressed = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_bg_low_pressed");
            notification_bg_normal = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_bg_normal");
            notification_bg_normal_pressed = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_bg_normal_pressed");
            notification_icon_background = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_icon_background");
            notification_template_icon_bg = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_template_icon_bg");
            notification_template_icon_low_bg = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_template_icon_low_bg");
            notification_tile_bg = com.zqy.googlelib.ResourcesUtil.getDrawableId("notification_tile_bg");
            notify_panel_notification_icon_bg = com.zqy.googlelib.ResourcesUtil.getDrawableId("notify_panel_notification_icon_bg");
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material;
        public static final int compat_button_inset_vertical_material;
        public static final int compat_button_padding_horizontal_material;
        public static final int compat_button_padding_vertical_material;
        public static final int compat_control_corner_material;
        public static final int compat_notification_large_icon_max_height;
        public static final int compat_notification_large_icon_max_width;
        public static final int notification_action_icon_size;
        public static final int notification_action_text_size;
        public static final int notification_big_circle_margin;
        public static final int notification_content_margin_start;
        public static final int notification_large_icon_height;
        public static final int notification_large_icon_width;
        public static final int notification_main_column_padding_top;
        public static final int notification_media_narrow_margin;
        public static final int notification_right_icon_size;
        public static final int notification_right_side_padding_top;
        public static final int notification_small_icon_background_padding;
        public static final int notification_small_icon_size_as_large;
        public static final int notification_subtext_size;
        public static final int notification_top_pad;
        public static final int notification_top_pad_large_text;
        public static final int subtitle_corner_radius;
        public static final int subtitle_outline_width;
        public static final int subtitle_shadow_offset;
        public static final int subtitle_shadow_radius;

        public dimen() {
        }

        static {
            compat_button_inset_horizontal_material = com.zqy.googlelib.ResourcesUtil.getDimen("compat_button_inset_horizontal_material");
            compat_button_inset_vertical_material = com.zqy.googlelib.ResourcesUtil.getDimen("compat_button_inset_vertical_material");
            compat_button_padding_horizontal_material = com.zqy.googlelib.ResourcesUtil.getDimen("compat_button_padding_horizontal_material");
            compat_button_padding_vertical_material = com.zqy.googlelib.ResourcesUtil.getDimen("compat_button_padding_vertical_material");
            compat_control_corner_material = com.zqy.googlelib.ResourcesUtil.getDimen("compat_control_corner_material");
            compat_notification_large_icon_max_height = com.zqy.googlelib.ResourcesUtil.getDimen("compat_notification_large_icon_max_height");
            compat_notification_large_icon_max_width = com.zqy.googlelib.ResourcesUtil.getDimen("compat_notification_large_icon_max_width");
            notification_action_icon_size = com.zqy.googlelib.ResourcesUtil.getDimen("notification_action_icon_size");
            notification_action_text_size = com.zqy.googlelib.ResourcesUtil.getDimen("notification_action_text_size");
            notification_big_circle_margin = com.zqy.googlelib.ResourcesUtil.getDimen("notification_big_circle_margin");
            notification_content_margin_start = com.zqy.googlelib.ResourcesUtil.getDimen("notification_content_margin_start");
            notification_large_icon_height = com.zqy.googlelib.ResourcesUtil.getDimen("notification_large_icon_height");
            notification_large_icon_width = com.zqy.googlelib.ResourcesUtil.getDimen("notification_large_icon_width");
            notification_main_column_padding_top = com.zqy.googlelib.ResourcesUtil.getDimen("notification_main_column_padding_top");
            notification_media_narrow_margin = com.zqy.googlelib.ResourcesUtil.getDimen("notification_media_narrow_margin");
            notification_right_icon_size = com.zqy.googlelib.ResourcesUtil.getDimen("notification_right_icon_size");
            notification_right_side_padding_top = com.zqy.googlelib.ResourcesUtil.getDimen("notification_right_side_padding_top");
            notification_small_icon_background_padding = com.zqy.googlelib.ResourcesUtil.getDimen("notification_small_icon_background_padding");
            notification_small_icon_size_as_large = com.zqy.googlelib.ResourcesUtil.getDimen("notification_small_icon_size_as_large");
            notification_subtext_size = com.zqy.googlelib.ResourcesUtil.getDimen("notification_subtext_size");
            notification_top_pad = com.zqy.googlelib.ResourcesUtil.getDimen("notification_top_pad");
            notification_top_pad_large_text = com.zqy.googlelib.ResourcesUtil.getDimen("notification_top_pad_large_text");
            subtitle_corner_radius = com.zqy.googlelib.ResourcesUtil.getDimen("subtitle_corner_radius");
            subtitle_outline_width = com.zqy.googlelib.ResourcesUtil.getDimen("subtitle_outline_width");
            subtitle_shadow_offset = com.zqy.googlelib.ResourcesUtil.getDimen("subtitle_shadow_offset");
            subtitle_shadow_radius = com.zqy.googlelib.ResourcesUtil.getDimen("subtitle_shadow_radius");
        }
    }

    public static final class color {
        public static final int notification_action_color_filter;
        public static final int notification_icon_bg_color;
        public static final int notification_material_background_media_default_color;
        public static final int primary_text_default_material_dark;
        public static final int ripple_material_light;
        public static final int secondary_text_default_material_dark;
        public static final int secondary_text_default_material_light;

        public color() {
        }

        static {
            notification_action_color_filter = com.zqy.googlelib.ResourcesUtil.getColorId("notification_action_color_filter");
            notification_icon_bg_color = com.zqy.googlelib.ResourcesUtil.getColorId("notification_icon_bg_color");
            notification_material_background_media_default_color = com.zqy.googlelib.ResourcesUtil.getColorId("notification_material_background_media_default_color");
            primary_text_default_material_dark = com.zqy.googlelib.ResourcesUtil.getColorId("primary_text_default_material_dark");
            ripple_material_light = com.zqy.googlelib.ResourcesUtil.getColorId("ripple_material_light");
            secondary_text_default_material_dark = com.zqy.googlelib.ResourcesUtil.getColorId("secondary_text_default_material_dark");
            secondary_text_default_material_light = com.zqy.googlelib.ResourcesUtil.getColorId("secondary_text_default_material_light");
        }
    }

    public static final class attr {
        public static final int alpha;
        public static final int font;
        public static final int fontProviderAuthority;
        public static final int fontProviderCerts;
        public static final int fontProviderFetchStrategy;
        public static final int fontProviderFetchTimeout;
        public static final int fontProviderPackage;
        public static final int fontProviderQuery;
        public static final int fontStyle;
        public static final int fontVariationSettings;
        public static final int fontWeight;
        public static final int ttcIndex;

        public attr() {
        }

        static {
            alpha = com.zqy.googlelib.ResourcesUtil.getAttr("alpha");
            font = com.zqy.googlelib.ResourcesUtil.getAttr("font");
            fontProviderAuthority = com.zqy.googlelib.ResourcesUtil.getAttr("fontProviderAuthority");
            fontProviderCerts = com.zqy.googlelib.ResourcesUtil.getAttr("fontProviderCerts");
            fontProviderFetchStrategy = com.zqy.googlelib.ResourcesUtil.getAttr("fontProviderFetchStrategy");
            fontProviderFetchTimeout = com.zqy.googlelib.ResourcesUtil.getAttr("fontProviderFetchTimeout");
            fontProviderPackage = com.zqy.googlelib.ResourcesUtil.getAttr("fontProviderPackage");
            fontProviderQuery = com.zqy.googlelib.ResourcesUtil.getAttr("fontProviderQuery");
            fontStyle = com.zqy.googlelib.ResourcesUtil.getAttr("fontStyle");
            fontVariationSettings = com.zqy.googlelib.ResourcesUtil.getAttr("fontVariationSettings");
            fontWeight = com.zqy.googlelib.ResourcesUtil.getAttr("fontWeight");
            ttcIndex = com.zqy.googlelib.ResourcesUtil.getAttr("ttcIndex");
        }
    }
}